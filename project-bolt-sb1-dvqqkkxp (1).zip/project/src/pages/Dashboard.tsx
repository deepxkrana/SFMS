import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Plus, Share2, FolderPlus, Trash2 } from 'lucide-react';
import Header from '../components/layout/Header';
import Sidebar from '../components/layout/Sidebar';
import Breadcrumbs from '../components/files/Breadcrumbs';
import FileGrid from '../components/files/FileGrid';
import { Button } from '../components/ui/Button';
import useUIStore from '../store/uiStore';
import useFileStore from '../store/fileStore';
import UploadZone from '../components/upload/UploadZone';
import CreateFolderModal from '../components/modals/CreateFolderModal';
import ShareModal from '../components/modals/ShareModal';

const Dashboard: React.FC = () => {
  const { colorMode } = useUIStore();
  const { selectedItems, clearSelection, files, folders } = useFileStore();
  const [showUploadZone, setShowUploadZone] = useState(false);
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  
  // Find the name of the first selected item for the share modal
  const getSelectedItemName = (): string => {
    if (selectedItems.length === 0) return '';
    
    const selectedItemId = selectedItems[0];
    const file = files.find(f => f.id === selectedItemId);
    if (file) return file.name;
    
    const folder = folders.find(f => f.id === selectedItemId);
    if (folder) return folder.name;
    
    return '';
  };
  
  return (
    <div className={`min-h-screen ${colorMode === 'dark' ? 'dark' : ''}`}>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Sidebar 
          onUpload={() => setShowUploadZone(true)}
          onCreateFolder={() => setShowCreateFolder(true)}
        />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          <Header />
          
          <div className="flex-1 overflow-auto">
            <Breadcrumbs />
            
            {/* Action buttons */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => setShowUploadZone(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={() => setShowCreateFolder(true)}
                >
                  <FolderPlus className="h-4 w-4 mr-2" />
                  New Folder
                </Button>
              </div>
              
              {selectedItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center space-x-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-lg shadow-sm border dark:border-gray-700"
                >
                  <span className="text-sm font-medium mr-2">
                    {selectedItems.length} {selectedItems.length === 1 ? 'item' : 'items'} selected
                  </span>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      if (selectedItems.length === 1) {
                        setShowShareModal(true);
                      }
                    }}
                    disabled={selectedItems.length !== 1}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    disabled={selectedItems.length === 0}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    disabled={selectedItems.length === 0}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={clearSelection}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </motion.div>
              )}
            </div>
            
            <FileGrid />
          </div>
        </main>
        
        <AnimatePresence>
          {showUploadZone && (
            <UploadZone onClose={() => setShowUploadZone(false)} />
          )}
          
          {showCreateFolder && (
            <CreateFolderModal onClose={() => setShowCreateFolder(false)} />
          )}
          
          {showShareModal && selectedItems.length === 1 && (
            <ShareModal 
              itemId={selectedItems[0]} 
              itemName={getSelectedItemName()}
              onClose={() => setShowShareModal(false)} 
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

// These components are needed for Dashboard but not imported
// Adding them to make sure the component compiles correctly
const X = () => null;
const Download = () => null;

export default Dashboard;