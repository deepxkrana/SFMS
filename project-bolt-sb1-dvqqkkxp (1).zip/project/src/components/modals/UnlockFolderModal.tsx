import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, X } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import useFileStore from '../../store/fileStore';

interface UnlockFolderModalProps {
  folderId: string;
  folderName: string;
  onClose: () => void;
}

const UnlockFolderModal: React.FC<UnlockFolderModalProps> = ({ 
  folderId, 
  folderName, 
  onClose 
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { validateFolderPassword, navigateTo } = useFileStore();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!password.trim()) {
      setError('Password is required');
      return;
    }
    
    if (validateFolderPassword(folderId, password)) {
      navigateTo(folderId, password);
      onClose();
    } else {
      setError('Incorrect password');
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full"
      >
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <div className="flex items-center">
            <Lock className="h-5 w-5 text-blue-500 dark:text-blue-400 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Unlock Folder</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Enter the password to access "{folderName}"
          </p>
          
          <Input
            label="Password"
            id="password"
            name="password"
            type="password"
            placeholder="Enter folder password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setError('');
            }}
            error={error}
            autoFocus
            className="mb-4"
          />
          
          <div className="flex justify-end space-x-2 mt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit">
              Unlock
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default UnlockFolderModal;