import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FolderPlus, X, Lock } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import useFileStore from '../../store/fileStore';

interface CreateFolderModalProps {
  onClose: () => void;
}

const CreateFolderModal: React.FC<CreateFolderModalProps> = ({ onClose }) => {
  const [folderName, setFolderName] = useState('');
  const [isLocked, setIsLocked] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { createFolder, currentFolderId } = useFileStore();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!folderName.trim()) {
      setError('Folder name is required');
      return;
    }
    
    if (isLocked && !password.trim()) {
      setError('Password is required for locked folders');
      return;
    }
    
    createFolder(folderName, currentFolderId, isLocked, password);
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full"
      >
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <div className="flex items-center">
            <FolderPlus className="h-5 w-5 text-blue-500 dark:text-blue-400 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Create Folder</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4">
          <Input
            label="Folder Name"
            id="folderName"
            name="folderName"
            placeholder="Enter folder name"
            value={folderName}
            onChange={(e) => {
              setFolderName(e.target.value);
              setError('');
            }}
            error={error}
            autoFocus
            className="mb-4"
          />
          
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="isLocked"
              checked={isLocked}
              onChange={(e) => setIsLocked(e.target.checked)}
              className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="isLocked" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
              Lock folder with password
            </label>
          </div>
          
          {isLocked && (
            <Input
              label="Password"
              id="password"
              name="password"
              type="password"
              placeholder="Enter folder password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mb-4"
            />
          )}
          
          <div className="flex justify-end space-x-2 mt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit">
              Create Folder
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default CreateFolderModal;