import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import useFileStore from '../../store/fileStore';
import { motion } from 'framer-motion';

const Breadcrumbs: React.FC = () => {
  const { getCurrentPath, navigateTo } = useFileStore();
  const path = getCurrentPath();
  
  return (
    <nav className="flex px-4 py-3" aria-label="Breadcrumb">
      <ol className="inline-flex items-center space-x-1 md:space-x-2">
        {path.map((item, index) => {
          const isLast = index === path.length - 1;
          
          return (
            <React.Fragment key={item.id || 'home'}>
              {index > 0 && (
                <li className="flex items-center">
                  <ChevronRight className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                </li>
              )}
              
              <li className="flex items-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => navigateTo(item.id)}
                  className={`
                    inline-flex items-center text-sm font-medium
                    ${isLast
                      ? 'text-gray-700 dark:text-gray-300'
                      : 'text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400'
                    }
                  `}
                  aria-current={isLast ? 'page' : undefined}
                >
                  {index === 0 && (
                    <Home className="mr-1 h-4 w-4" />
                  )}
                  {item.name}
                </motion.button>
              </li>
            </React.Fragment>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumbs;