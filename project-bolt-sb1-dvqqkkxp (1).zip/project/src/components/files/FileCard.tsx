import React from 'react';
import { 
  File, 
  FileText, 
  FileImage, 
  FileSpreadsheet, 
  FileCode,
  Star,
  MoreVertical,
  Share2,
  Download,
  Pencil,
  Trash2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { FileItem } from '../../types';
import useFileStore from '../../store/fileStore';
import { format } from 'date-fns';

interface FileCardProps {
  file: FileItem;
  onSelect: (id: string, isSelected: boolean) => void;
  isSelected: boolean;
}

const FileCard: React.FC<FileCardProps> = ({ file, onSelect, isSelected }) => {
  const { toggleStar, deleteFile, renameFile } = useFileStore();
  const [showMenu, setShowMenu] = React.useState(false);
  const [isRenaming, setIsRenaming] = React.useState(false);
  const [newName, setNewName] = React.useState(file.name);
  const menuRef = React.useRef<HTMLDivElement>(null);
  
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const getFileIcon = () => {
    if (file.type.startsWith('image/')) {
      return <FileImage className="h-8 w-8 text-blue-500" />;
    } else if (file.type.includes('spreadsheet') || file.type.includes('excel')) {
      return <FileSpreadsheet className="h-8 w-8 text-green-500" />;
    } else if (file.type.includes('document') || file.type.includes('word')) {
      return <FileText className="h-8 w-8 text-blue-500" />;
    } else if (file.type.includes('code') || file.type.includes('json') || file.type.includes('html')) {
      return <FileCode className="h-8 w-8 text-purple-500" />;
    } else {
      return <File className="h-8 w-8 text-gray-500" />;
    }
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const handleRename = () => {
    setIsRenaming(true);
    setShowMenu(false);
  };
  
  const submitRename = () => {
    if (newName.trim() && newName !== file.name) {
      renameFile(file.id, newName);
    }
    setIsRenaming(false);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      className={`
        relative p-4 rounded-lg border transition-colors
        ${isSelected 
          ? 'border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/20' 
          : 'border-gray-200 bg-white hover:border-blue-300 dark:border-gray-700 dark:bg-gray-800 dark:hover:border-blue-700'}
      `}
      onClick={() => onSelect(file.id, !isSelected)}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          {file.thumbnail ? (
            <img 
              src={file.thumbnail} 
              alt={file.name} 
              className="h-10 w-10 rounded object-cover"
            />
          ) : (
            getFileIcon()
          )}
          
          <div>
            {isRenaming ? (
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onBlur={submitRename}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submitRename();
                    if (e.key === 'Escape') {
                      setNewName(file.name);
                      setIsRenaming(false);
                    }
                  }}
                  className="text-sm font-medium border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  autoFocus
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            ) : (
              <h3 className="text-sm font-medium text-gray-900 dark:text-white line-clamp-1">
                {file.name}
              </h3>
            )}
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {formatFileSize(file.size)} · {format(file.updatedAt, 'MMM d, yyyy')}
            </p>
          </div>
        </div>
        
        <div className="flex items-center">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleStar(file.id);
            }}
            className="mr-1"
          >
            <Star 
              className={`h-5 w-5 ${file.isStarred ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`} 
            />
          </button>
          
          <div className="relative" ref={menuRef}>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
            >
              <MoreVertical className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            </button>
            
            {showMenu && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none dark:bg-gray-800 dark:ring-gray-700"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="py-1">
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Download functionality would be implemented here
                      setShowMenu(false);
                    }}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </button>
                  
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRename();
                    }}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Rename
                  </button>
                  
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Share functionality would be implemented here
                      setShowMenu(false);
                    }}
                  >
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </button>
                  
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:text-red-400 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteFile(file.id);
                      setShowMenu(false);
                    }}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
      
      {file.isShared && (
        <div className="absolute top-2 right-2">
          <div className="rounded-full bg-blue-100 p-1 dark:bg-blue-900">
            <Share2 className="h-3 w-3 text-blue-500 dark:text-blue-400" />
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default FileCard;