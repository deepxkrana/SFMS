import React from 'react';
import { 
  Folder, 
  MoreVertical, 
  Pencil, 
  Share2, 
  Trash2,
  Lock,
  Unlock
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Folder as FolderType } from '../../types';
import useFileStore from '../../store/fileStore';
import { format } from 'date-fns';

interface FolderCardProps {
  folder: FolderType;
  onOpen: (id: string) => void;
  onSelect: (id: string, isSelected: boolean) => void;
  isSelected: boolean;
  onUnlock: (id: string, name: string) => void;
}

const FolderCard: React.FC<FolderCardProps> = ({ 
  folder, 
  onOpen, 
  onSelect, 
  isSelected,
  onUnlock
}) => {
  const { deleteFolder, renameFolder, lockFolder, unlockFolder } = useFileStore();
  const [showMenu, setShowMenu] = React.useState(false);
  const [isRenaming, setIsRenaming] = React.useState(false);
  const [newName, setNewName] = React.useState(folder.name);
  const menuRef = React.useRef<HTMLDivElement>(null);
  
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const handleRename = () => {
    setIsRenaming(true);
    setShowMenu(false);
  };
  
  const submitRename = () => {
    if (newName.trim() && newName !== folder.name) {
      renameFolder(folder.id, newName);
    }
    setIsRenaming(false);
  };

  const handleFolderClick = (e: React.MouseEvent) => {
    if (!isRenaming) {
      if (folder.isLocked) {
        e.stopPropagation();
        onUnlock(folder.id, folder.name);
      } else {
        onSelect(folder.id, !isSelected);
      }
    }
  };

  const handleFolderDoubleClick = () => {
    if (!isRenaming && !folder.isLocked) {
      onOpen(folder.id);
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      className={`
        relative p-4 rounded-lg border cursor-pointer transition-colors
        ${isSelected 
          ? 'border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/20' 
          : 'border-gray-200 bg-white hover:border-blue-300 dark:border-gray-700 dark:bg-gray-800 dark:hover:border-blue-700'}
      `}
      onClick={handleFolderClick}
      onDoubleClick={handleFolderDoubleClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <Folder className="h-8 w-8 text-yellow-500 dark:text-yellow-400" />
          
          <div>
            {isRenaming ? (
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onBlur={submitRename}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submitRename();
                    if (e.key === 'Escape') {
                      setNewName(folder.name);
                      setIsRenaming(false);
                    }
                  }}
                  className="text-sm font-medium border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  autoFocus
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-medium text-gray-900 dark:text-white line-clamp-1">
                  {folder.name}
                </h3>
                {folder.isLocked && (
                  <Lock className="h-4 w-4 text-blue-500 dark:text-blue-400" />
                )}
              </div>
            )}
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {format(folder.updatedAt, 'MMM d, yyyy')}
            </p>
          </div>
        </div>
        
        <div className="relative" ref={menuRef}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
          >
            <MoreVertical className="h-5 w-5 text-gray-500 dark:text-gray-400" />
          </button>
          
          {showMenu && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none dark:bg-gray-800 dark:ring-gray-700"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="py-1">
                {!folder.isLocked && (
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpen(folder.id);
                    }}
                  >
                    <Folder className="mr-2 h-4 w-4" />
                    Open
                  </button>
                )}
                
                <button
                  className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRename();
                  }}
                >
                  <Pencil className="mr-2 h-4 w-4" />
                  Rename
                </button>
                
                <button
                  className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                  onClick={(e) => {
                    e.stopPropagation();
                    // Share functionality would be implemented here
                    setShowMenu(false);
                  }}
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </button>

                {folder.isLocked ? (
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      unlockFolder(folder.id);
                      setShowMenu(false);
                    }}
                  >
                    <Unlock className="mr-2 h-4 w-4" />
                    Remove Password
                  </button>
                ) : (
                  <button
                    className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      const password = prompt('Enter a password for the folder:');
                      if (password) {
                        lockFolder(folder.id, password);
                      }
                      setShowMenu(false);
                    }}
                  >
                    <Lock className="mr-2 h-4 w-4" />
                    Set Password
                  </button>
                )}
                
                <button
                  className="flex w-full items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:text-red-400 dark:hover:bg-gray-700"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteFolder(folder.id);
                    setShowMenu(false);
                  }}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
      
      {folder.isShared && (
        <div className="absolute top-2 right-2">
          <div className="rounded-full bg-blue-100 p-1 dark:bg-blue-900">
            <Share2 className="h-3 w-3 text-blue-500 dark:text-blue-400" />
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default FolderCard;