import React, { useState } from 'react';
import { motion } from 'framer-motion';
import useFileStore from '../../store/fileStore';
import FileCard from './FileCard';
import FolderCard from './FolderCard';
import useUIStore from '../../store/uiStore';
import { FileItem, Folder } from '../../types';
import { format } from 'date-fns';
import { MoreVertical, Folder as FolderIcon, File, Star } from 'lucide-react';
import UnlockFolderModal from '../modals/UnlockFolderModal';

const FileGrid: React.FC = () => {
  const { 
    files, 
    folders, 
    currentFolderId, 
    navigateTo,
    selectedItems,
    selectItem,
    deselectItem,
    searchQuery,
    sortBy,
    viewMode
  } = useFileStore();
  
  const { activeTab } = useUIStore();
  const [unlockFolder, setUnlockFolder] = useState<{ id: string; name: string } | null>(null);
  
  // Filter files and folders based on current location and active tab
  const filteredFolders = folders.filter(folder => {
    if (searchQuery) {
      return folder.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
             folder.parentId === currentFolderId;
    }
    
    if (activeTab === 'files') {
      return folder.parentId === currentFolderId;
    } else if (activeTab === 'shared') {
      return folder.isShared;
    } else if (activeTab === 'starred') {
      return false; // Folders can't be starred in this implementation
    } else {
      return folder.parentId === currentFolderId;
    }
  });
  
  const filteredFiles = files.filter(file => {
    if (searchQuery) {
      return file.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
             file.parentId === currentFolderId;
    }
    
    if (activeTab === 'files') {
      return file.parentId === currentFolderId;
    } else if (activeTab === 'shared') {
      return file.isShared;
    } else if (activeTab === 'starred') {
      return file.isStarred;
    } else {
      return file.parentId === currentFolderId;
    }
  });
  
  // Sort files and folders
  const sortItems = <T extends FileItem | Folder>(items: T[]): T[] => {
    return [...items].sort((a, b) => {
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      } else if (sortBy === 'date') {
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      } else if (sortBy === 'size' && 'size' in a && 'size' in b) {
        return (b as FileItem).size - (a as FileItem).size;
      } else if (sortBy === 'type' && 'type' in a && 'type' in b) {
        return (a as FileItem).type.localeCompare((b as FileItem).type);
      }
      return 0;
    });
  };
  
  const sortedFolders = sortItems(filteredFolders);
  const sortedFiles = sortItems(filteredFiles);
  
  const handleSelectItem = (id: string, isSelected: boolean) => {
    if (isSelected) {
      selectItem(id);
    } else {
      deselectItem(id);
    }
  };

  const handleUnlockFolder = (id: string, name: string) => {
    setUnlockFolder({ id, name });
  };
  
  // No files or folders to display
  if (sortedFolders.length === 0 && sortedFiles.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center h-64 text-center p-4"
      >
        <div className="rounded-full bg-blue-100 p-4 dark:bg-blue-900 mb-4">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-8 w-8 text-blue-600 dark:text-blue-400" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" 
            />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">No items found</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {searchQuery 
            ? "No results match your search criteria" 
            : activeTab === 'starred' 
              ? "You haven't starred any files yet" 
              : activeTab === 'shared' 
                ? "You don't have any shared files yet"
                : "Upload files or create folders to get started"}
        </p>
      </motion.div>
    );
  }
  
  // Show files and folders in grid or list view
  return (
    <>
      <div className={`p-4 ${viewMode === 'grid' ? 'grid-view' : 'list-view'}`}>
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {sortedFolders.map(folder => (
              <FolderCard 
                key={folder.id} 
                folder={folder} 
                onOpen={(id) => navigateTo(id)} 
                onSelect={handleSelectItem}
                isSelected={selectedItems.includes(folder.id)}
                onUnlock={handleUnlockFolder}
              />
            ))}
            
            {sortedFiles.map(file => (
              <FileCard 
                key={file.id} 
                file={file} 
                onSelect={handleSelectItem}
                isSelected={selectedItems.includes(file.id)}
              />
            ))}
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            {/* List view header */}
            <div className="bg-gray-50 dark:bg-gray-800 p-3 grid grid-cols-12 gap-4 text-xs font-medium text-gray-500 dark:text-gray-400">
              <div className="col-span-6">Name</div>
              <div className="col-span-2 hidden sm:block">Size</div>
              <div className="col-span-3 hidden sm:block">Modified</div>
              <div className="col-span-1"></div>
            </div>
            
            {/* Folders */}
            {sortedFolders.map(folder => (
              <div 
                key={folder.id}
                className={`
                  p-3 grid grid-cols-12 gap-4 items-center text-sm cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800
                  ${selectedItems.includes(folder.id) ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-white dark:bg-gray-900'}
                `}
                onClick={() => {
                  if (folder.isLocked) {
                    handleUnlockFolder(folder.id, folder.name);
                  } else {
                    handleSelectItem(folder.id, !selectedItems.includes(folder.id));
                  }
                }}
                onDoubleClick={() => {
                  if (!folder.isLocked) {
                    navigateTo(folder.id);
                  }
                }}
              >
                <div className="col-span-6 flex items-center space-x-3">
                  <FolderIcon className="h-5 w-5 text-yellow-500 dark:text-yellow-400" />
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-gray-900 dark:text-white">{folder.name}</span>
                    {folder.isLocked && (
                      <Lock className="h-4 w-4 text-blue-500 dark:text-blue-400" />
                    )}
                  </div>
                  {folder.isShared && (
                    <div className="rounded-full bg-blue-100 p-1 dark:bg-blue-900">
                      <Share2 className="h-3 w-3 text-blue-500 dark:text-blue-400" />
                    </div>
                  )}
                </div>
                <div className="col-span-2 hidden sm:block text-gray-500 dark:text-gray-400">Folder</div>
                <div className="col-span-3 hidden sm:block text-gray-500 dark:text-gray-400">
                  {format(folder.updatedAt, 'MMM d, yyyy')}
                </div>
                <div className="col-span-1 flex justify-end">
                  <button>
                    <MoreVertical className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                  </button>
                </div>
              </div>
            ))}
            
            {/* Files */}
            {sortedFiles.map(file => (
              <div 
                key={file.id}
                className={`
                  p-3 grid grid-cols-12 gap-4 items-center text-sm cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800
                  ${selectedItems.includes(file.id) ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-white dark:bg-gray-900'}
                `}
                onClick={() => handleSelectItem(file.id, !selectedItems.includes(file.id))}
              >
                <div className="col-span-6 flex items-center space-x-3">
                  {file.thumbnail ? (
                    <img 
                      src={file.thumbnail} 
                      alt={file.name} 
                      className="h-8 w-8 rounded object-cover" 
                    />
                  ) : (
                    <File className="h-5 w-5 text-blue-500 dark:text-blue-400" />
                  )}
                  <span className="font-medium text-gray-900 dark:text-white">{file.name}</span>
                  {file.isShared && (
                    <div className="rounded-full bg-blue-100 p-1 dark:bg-blue-900">
                      <Share2 className="h-3 w-3 text-blue-500 dark:text-blue-400" />
                    </div>
                  )}
                  {file.isStarred && (
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  )}
                </div>
                <div className="col-span-2 hidden sm:block text-gray-500 dark:text-gray-400">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </div>
                <div className="col-span-3 hidden sm:block text-gray-500 dark:text-gray-400">
                  {format(file.updatedAt, 'MMM d, yyyy')}
                </div>
                <div className="col-span-1 flex justify-end">
                  <button>
                    <MoreVertical className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {unlockFolder && (
        <UnlockFolderModal
          folderId={unlockFolder.id}
          folderName={unlockFolder.name}
          onClose={() => setUnlockFolder(null)}
        />
      )}
    </>
  );
};

export default FileGrid;