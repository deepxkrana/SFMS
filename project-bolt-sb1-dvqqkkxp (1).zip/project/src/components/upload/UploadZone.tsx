import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import useFileStore from '../../store/fileStore';
import { Button } from '../ui/Button';

const UploadZone: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { addFile, currentFolderId } = useFileStore();
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [uploading, setUploading] = useState(false);
  
  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(prev => [...prev, ...acceptedFiles]);
  }, []);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
  });
  
  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleUpload = async () => {
    if (files.length === 0) return;
    
    setUploading(true);
    
    // Create initial progress for all files
    const initialProgress: Record<string, number> = {};
    files.forEach((file, index) => {
      initialProgress[index.toString()] = 0;
    });
    setUploadProgress(initialProgress);
    
    // Upload files one by one
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      try {
        // Simulate progress updates
        for (let progress = 0; progress <= 100; progress += 10) {
          setUploadProgress(prev => ({
            ...prev,
            [i.toString()]: progress
          }));
          
          // Simulate upload delay
          await new Promise(resolve => setTimeout(resolve, 200));
        }
        
        // Add file to store
        await addFile(file, currentFolderId);
        
      } catch (error) {
        console.error('Error uploading file:', error);
      }
    }
    
    setUploading(false);
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] flex flex-col"
      >
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Upload Files</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex-1 overflow-auto p-4">
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
              ${isDragActive 
                ? 'border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/20' 
                : 'border-gray-300 dark:border-gray-700'}
            `}
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
            <p className="mt-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              {isDragActive 
                ? 'Drop the files here...' 
                : 'Drag & drop files here, or click to select files'}
            </p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Upload any file type. Max file size: 100MB.
            </p>
          </div>
          
          {files.length > 0 && (
            <div className="mt-6">
              <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">
                Selected Files ({files.length})
              </h3>
              
              <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                <AnimatePresence>
                  {files.map((file, index) => (
                    <motion.div
                      key={`${file.name}-${index}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, height: 0 }}
                      className="flex items-center justify-between bg-gray-50 dark:bg-gray-800 p-3 rounded-lg"
                    >
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <div className="w-10 h-10 rounded bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                          <span className="text-xs font-medium text-gray-600 dark:text-gray-300">
                            {file.name.split('.').pop()?.toUpperCase()}
                          </span>
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                            {file.name}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                      
                      {uploading ? (
                        <div className="w-24">
                          <div className="h-2 w-full bg-gray-200 rounded-full dark:bg-gray-700">
                            <div 
                              className="h-2 rounded-full bg-blue-600 dark:bg-blue-500" 
                              style={{ width: `${uploadProgress[index.toString()] || 0}%` }}
                            ></div>
                          </div>
                          <p className="text-xs text-center mt-1 text-gray-500 dark:text-gray-400">
                            {uploadProgress[index.toString()] || 0}%
                          </p>
                        </div>
                      ) : (
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => removeFile(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>
        
        <div className="border-t dark:border-gray-700 p-4 flex justify-end space-x-2">
          <Button 
            variant="outline" 
            onClick={onClose}
            disabled={uploading}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleUpload}
            disabled={files.length === 0 || uploading}
            isLoading={uploading}
          >
            {uploading ? 'Uploading...' : 'Upload Files'}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default UploadZone;