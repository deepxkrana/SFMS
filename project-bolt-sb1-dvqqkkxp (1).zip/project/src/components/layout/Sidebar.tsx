import React from 'react';
import { 
  Database, 
  Share2, 
  Star, 
  Trash2, 
  Plus, 
  FolderPlus,
  Upload,
  ShieldCheck
} from 'lucide-react';
import { Button } from '../ui/Button';
import useUIStore from '../../store/uiStore';
import { motion } from 'framer-motion';

interface SidebarProps {
  onUpload: () => void;
  onCreateFolder: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onUpload, onCreateFolder }) => {
  const { isSidebarOpen, activeTab, setActiveTab } = useUIStore();
  
  if (!isSidebarOpen) return null;
  
  return (
    <motion.aside
      initial={{ x: -200, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -200, opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="hidden md:flex flex-col w-64 border-r border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 z-20"
    >
      <div className="flex h-16 items-center border-b border-gray-200 px-6 dark:border-gray-800">
        <ShieldCheck className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-2" />
        <h1 className="text-xl font-semibold text-gray-900 dark:text-white">SecureFiles</h1>
      </div>
      
      <div className="p-4">
        <Button 
          className="w-full justify-start mb-2 bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.multiple = true;
            fileInput.onchange = () => {
              if (fileInput.files?.length) {
                onUpload();
              }
            };
            fileInput.click();
          }}
        >
          <Upload className="mr-2 h-4 w-4" />
          Upload files
        </Button>
        
        <Button 
          variant="outline" 
          className="w-full justify-start"
          onClick={onCreateFolder}
        >
          <FolderPlus className="mr-2 h-4 w-4" />
          New folder
        </Button>
      </div>
      
      <nav className="flex-1 space-y-1 px-2 py-4">
        <button
          className={`
            flex w-full items-center rounded-md px-3 py-2 text-sm font-medium
            ${activeTab === 'files' 
              ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' 
              : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'}
          `}
          onClick={() => setActiveTab('files')}
        >
          <Database className="mr-2 h-4 w-4" />
          My Files
        </button>
        
        <button
          className={`
            flex w-full items-center rounded-md px-3 py-2 text-sm font-medium
            ${activeTab === 'shared' 
              ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' 
              : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'}
          `}
          onClick={() => setActiveTab('shared')}
        >
          <Share2 className="mr-2 h-4 w-4" />
          Shared
        </button>
        
        <button
          className={`
            flex w-full items-center rounded-md px-3 py-2 text-sm font-medium
            ${activeTab === 'starred' 
              ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' 
              : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'}
          `}
          onClick={() => setActiveTab('starred')}
        >
          <Star className="mr-2 h-4 w-4" />
          Starred
        </button>
        
        <button
          className={`
            flex w-full items-center rounded-md px-3 py-2 text-sm font-medium
            ${activeTab === 'trash' 
              ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' 
              : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'}
          `}
          onClick={() => setActiveTab('trash')}
        >
          <Trash2 className="mr-2 h-4 w-4" />
          Trash
        </button>
      </nav>
      
      <div className="border-t border-gray-200 p-4 dark:border-gray-800">
        <div className="flex items-center">
          <div className="h-2 w-2 rounded-full bg-green-400 mr-2"></div>
          <div className="text-sm">
            <p className="font-medium text-gray-700 dark:text-gray-300">Storage</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">8.2 GB / 15 GB used</p>
          </div>
        </div>
        <div className="mt-2 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700">
          <div className="h-2 rounded-full bg-blue-600 dark:bg-blue-500" style={{ width: '55%' }}></div>
        </div>
      </div>
    </motion.aside>
  );
};

export default Sidebar;