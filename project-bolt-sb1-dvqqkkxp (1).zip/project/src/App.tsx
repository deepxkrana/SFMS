import React, { useEffect } from 'react';
import AuthForm from './components/auth/AuthForm';
import Dashboard from './pages/Dashboard';
import useAuthStore from './store/authStore';
import useUIStore from './store/uiStore';

function App() {
  const { isAuthenticated } = useAuthStore();
  const { colorMode } = useUIStore();
  
  // Apply color mode to document
  useEffect(() => {
    if (colorMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [colorMode]);

  return (
    <div className="App">
      {isAuthenticated ? <Dashboard /> : <AuthForm />}
    </div>
  );
}

export default App;