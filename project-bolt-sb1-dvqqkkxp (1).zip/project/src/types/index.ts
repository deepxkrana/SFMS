export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface FileItem {
  id: string;
  name: string;
  type: string;
  size: number;
  createdAt: Date;
  updatedAt: Date;
  ownerId: string;
  parentId: string | null;
  isStarred: boolean;
  isShared: boolean;
  sharedWith: string[];
  thumbnail?: string;
}

export interface Folder {
  id: string;
  name: string;
  createdAt: Date;
  updatedAt: Date;
  ownerId: string;
  parentId: string | null;
  isShared: boolean;
  sharedWith: string[];
  isLocked?: boolean;
  password?: string;
}

export type SortOption = 'name' | 'date' | 'size' | 'type';
export type ViewMode = 'grid' | 'list';
export type ColorMode = 'light' | 'dark';

export type Permission = 'view' | 'edit' | 'none';

export interface ShareSettings {
  userId: string;
  permission: Permission;
}