import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { FileItem, Folder, SortOption, ViewMode } from '../types';

interface FileState {
  files: FileItem[];
  folders: Folder[];
  currentFolderId: string | null;
  selectedItems: string[];
  sortBy: SortOption;
  viewMode: ViewMode;
  isLoading: boolean;
  searchQuery: string;
  
  // Navigation
  navigateTo: (folderId: string | null, password?: string) => void;
  getCurrentPath: () => { id: string | null; name: string }[];
  
  // File operations
  addFile: (file: File, parentId: string | null) => Promise<void>;
  moveFile: (fileId: string, destinationId: string | null) => void;
  deleteFile: (fileId: string) => void;
  renameFile: (fileId: string, newName: string) => void;
  toggleStar: (fileId: string) => void;
  
  // Folder operations
  createFolder: (name: string, parentId: string | null, isLocked?: boolean, password?: string) => void;
  deleteFolder: (folderId: string) => void;
  renameFolder: (folderId: string, newName: string) => void;
  lockFolder: (folderId: string, password: string) => void;
  unlockFolder: (folderId: string) => void;
  validateFolderPassword: (folderId: string, password: string) => boolean;
  
  // Selection
  selectItem: (id: string) => void;
  deselectItem: (id: string) => void;
  clearSelection: () => void;
  
  // View options
  setSortBy: (sortOption: SortOption) => void;
  setViewMode: (mode: ViewMode) => void;
  setSearchQuery: (query: string) => void;
  
  // Sharing
  shareItem: (itemId: string, userEmail: string) => void;
  unshareItem: (itemId: string, userId: string) => void;
}

const useFileStore = create<FileState>()(
  persist(
    (set, get) => ({
      // ... (keep existing state)
      
      navigateTo: (folderId, password) => {
        const { folders } = get();
        const folder = folders.find(f => f.id === folderId);
        
        if (folder?.isLocked && !password) {
          // Don't navigate if folder is locked and no password provided
          return;
        }
        
        if (folder?.isLocked && password) {
          // Validate password before navigation
          if (folder.password !== password) {
            return;
          }
        }
        
        set({ currentFolderId: folderId, selectedItems: [] });
      },

      getCurrentPath: () => {
        const { folders, currentFolderId } = get();
        const path: { id: string | null; name: string }[] = [
          { id: null, name: 'Home' }
        ];

        if (!currentFolderId) return path;

        const buildPath = (folderId: string) => {
          const folder = folders.find(f => f.id === folderId);
          if (!folder) return;

          if (folder.parentId) {
            buildPath(folder.parentId);
          }
          
          path.push({ id: folder.id, name: folder.name });
        };

        buildPath(currentFolderId);
        return path;
      },
      
      createFolder: (name, parentId, isLocked = false, password = '') => {
        const newFolder: Folder = {
          id: `folder${Date.now()}`,
          name,
          createdAt: new Date(),
          updatedAt: new Date(),
          ownerId: '1', // Current user ID
          parentId,
          isShared: false,
          sharedWith: [],
          isLocked,
          password: isLocked ? password : undefined,
        };
        
        set(state => ({
          folders: [...state.folders, newFolder]
        }));
      },
      
      lockFolder: (folderId, password) => {
        set(state => ({
          folders: state.folders.map(folder =>
            folder.id === folderId
              ? { ...folder, isLocked: true, password }
              : folder
          )
        }));
      },
      
      unlockFolder: (folderId) => {
        set(state => ({
          folders: state.folders.map(folder =>
            folder.id === folderId
              ? { ...folder, isLocked: false, password: undefined }
              : folder
          )
        }));
      },
      
      validateFolderPassword: (folderId, password) => {
        const { folders } = get();
        const folder = folders.find(f => f.id === folderId);
        return folder?.password === password;
      },
      
      // ... (keep rest of the existing code)
    }),
    {
      name: 'files-storage',
    }
  )
);

export default useFileStore;