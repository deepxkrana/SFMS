import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

// Mock authentication - in a real app, this would connect to a secure backend
const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      login: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 800));
          
          // Mock successful login - in a real app, this would validate credentials
          if (email === 'demo@example.com' && password === 'password') {
            set({
              user: {
                id: '1',
                name: 'Demo User',
                email: 'demo@example.com',
                avatar: 'https://i.pravatar.cc/150?u=demo@example.com',
              },
              isAuthenticated: true,
              isLoading: false,
            });
          } else {
            set({ error: 'Invalid email or password', isLoading: false });
          }
        } catch (error) {
          set({ error: 'Login failed. Please try again.', isLoading: false });
        }
      },
      signup: async (name, email, password) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 800));
          
          // Mock successful signup
          set({
            user: {
              id: '1',
              name,
              email,
              avatar: `https://i.pravatar.cc/150?u=${email}`,
            },
            isAuthenticated: true,
            isLoading: false,
          });
        } catch (error) {
          set({ error: 'Signup failed. Please try again.', isLoading: false });
        }
      },
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);

export default useAuthStore;