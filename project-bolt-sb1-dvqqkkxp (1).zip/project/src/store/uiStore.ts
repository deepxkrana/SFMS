import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ColorMode } from '../types';

interface UIState {
  colorMode: ColorMode;
  isSidebarOpen: boolean;
  isDetailsOpen: boolean;
  activeTab: 'files' | 'shared' | 'starred' | 'trash';
  toggleColorMode: () => void;
  toggleSidebar: () => void;
  toggleDetails: () => void;
  setActiveTab: (tab: 'files' | 'shared' | 'starred' | 'trash') => void;
}

const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      colorMode: 'light',
      isSidebarOpen: true,
      isDetailsOpen: false,
      activeTab: 'files',
      
      toggleColorMode: () => {
        set(state => ({ 
          colorMode: state.colorMode === 'light' ? 'dark' : 'light' 
        }));
      },
      
      toggleSidebar: () => {
        set(state => ({ isSidebarOpen: !state.isSidebarOpen }));
      },
      
      toggleDetails: () => {
        set(state => ({ isDetailsOpen: !state.isDetailsOpen }));
      },
      
      setActiveTab: (tab) => {
        set({ activeTab: tab });
      },
    }),
    {
      name: 'ui-storage',
    }
  )
);

export default useUIStore;